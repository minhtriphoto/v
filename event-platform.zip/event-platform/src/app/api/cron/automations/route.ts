import { NextResponse } from "next/server";
import { processDueEnrollments } from "@/lib/automation-engine";

// Gọi định kỳ bởi Vercel Cron (xem vercel.json) hoặc dịch vụ cron ngoài
// (vd cron-job.org) — bảo vệ bằng CRON_SECRET để tránh bị gọi tuỳ ý.
export async function GET(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (secret) {
    const auth = req.headers.get("authorization");
    const urlSecret = new URL(req.url).searchParams.get("secret");
    const provided = auth === `Bearer ${secret}` || urlSecret === secret;
    if (!provided) {
      return NextResponse.json({ error: "Không có quyền truy cập" }, { status: 401 });
    }
  }

  const result = await processDueEnrollments(200);
  return NextResponse.json(result);
}
