import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { appendSheetRowsWithToken, refreshAccessToken } from "@/lib/google-sheets";

export async function POST() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const integration = await prisma.integration.findUnique({
    where: { ownerId_type: { ownerId: userId, type: "GOOGLE_SHEETS" } },
  });
  const cfg = integration?.config as
    | { refreshToken: string; spreadsheetId?: string; sheetName?: string }
    | undefined;

  if (!cfg?.spreadsheetId || !cfg?.sheetName) {
    return NextResponse.json(
      { error: "Vui lòng cấu hình Spreadsheet ID và tên sheet trước" },
      { status: 400 }
    );
  }

  const events = await prisma.event.findMany({
    where: { ownerId: userId },
    include: {
      questions: { orderBy: { order: "asc" } },
      registrations: { include: { answers: true }, orderBy: { registeredAt: "asc" } },
    },
  });

  const rows: string[][] = [];
  for (const event of events) {
    for (const reg of event.registrations) {
      const byQuestion = Object.fromEntries(
        reg.answers.map((a) => [a.questionId, a.value])
      );
      rows.push([
        reg.registeredAt.toISOString(),
        event.title,
        reg.name,
        reg.email,
        reg.status,
        ...event.questions.map((q) => byQuestion[q.id] ?? ""),
      ]);
    }
  }

  if (rows.length === 0) {
    return NextResponse.json({ ok: true, synced: 0, failed: 0 });
  }

  const accessToken = await refreshAccessToken(cfg.refreshToken);
  if (!accessToken) {
    return NextResponse.json(
      { error: "Không thể làm mới access token Google — hãy kết nối lại" },
      { status: 400 }
    );
  }

  // Google Sheets API giới hạn kích thước 1 request — chia thành từng lô 500 dòng
  const BATCH_SIZE = 500;
  let synced = 0;
  let failed = 0;
  for (let i = 0; i < rows.length; i += BATCH_SIZE) {
    const batch = rows.slice(i, i + BATCH_SIZE);
    const result = await appendSheetRowsWithToken({
      accessToken,
      spreadsheetId: cfg.spreadsheetId,
      sheetName: cfg.sheetName,
      rows: batch,
    });
    if (result.ok) synced += batch.length;
    else failed += batch.length;
  }

  return NextResponse.json({ ok: true, synced, failed });
}

