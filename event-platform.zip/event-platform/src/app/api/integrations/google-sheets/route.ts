import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { verifySpreadsheetAccess } from "@/lib/google-sheets";

const schema = z.object({
  spreadsheetId: z.string().min(1, "Vui lòng nhập Spreadsheet ID"),
  sheetName: z.string().min(1, "Vui lòng nhập tên sheet (tab)"),
});

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const integration = await prisma.integration.findUnique({
    where: { ownerId_type: { ownerId: userId, type: "GOOGLE_SHEETS" } },
  });
  if (!integration) {
    return NextResponse.json(
      { error: "Chưa kết nối tài khoản Google — hãy kết nối trước" },
      { status: 400 }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }
  const { spreadsheetId, sheetName } = parsed.data;

  const cfg = integration.config as unknown as {
    refreshToken: string;
    googleEmail: string;
  };

  const check = await verifySpreadsheetAccess({
    refreshToken: cfg.refreshToken,
    spreadsheetId,
  });
  if (!check.ok) {
    return NextResponse.json({ error: check.error }, { status: 400 });
  }

  await prisma.integration.update({
    where: { ownerId_type: { ownerId: userId, type: "GOOGLE_SHEETS" } },
    data: {
      config: {
        ...cfg,
        spreadsheetId,
        sheetName,
      },
    },
  });

  return NextResponse.json({ ok: true, sheetTitle: check.title });
}

export async function DELETE() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  await prisma.integration
    .delete({
      where: { ownerId_type: { ownerId: userId, type: "GOOGLE_SHEETS" } },
    })
    .catch(() => null);

  return NextResponse.json({ ok: true });
}
