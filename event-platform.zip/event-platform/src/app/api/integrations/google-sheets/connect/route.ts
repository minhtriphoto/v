import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { buildGoogleSheetsAuthUrl } from "@/lib/google-sheets";
import { signState } from "@/lib/oauth-state";

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.redirect(
      new URL("/login", process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000")
    );
  }
  if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
    return NextResponse.redirect(
      new URL(
        "/dashboard/settings/integrations?error=google_not_configured",
        process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"
      )
    );
  }

  const userId = (session.user as { id: string }).id;
  const state = signState(userId);
  const authUrl = buildGoogleSheetsAuthUrl(state);

  return NextResponse.redirect(authUrl);
}
