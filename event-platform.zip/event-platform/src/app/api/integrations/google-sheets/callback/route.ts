import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { exchangeCodeForTokens, getGoogleEmail } from "@/lib/google-sheets";
import { verifyState } from "@/lib/oauth-state";

function redirectTo(path: string) {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  return NextResponse.redirect(new URL(path, base));
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const error = url.searchParams.get("error");

  if (error) {
    return redirectTo("/dashboard/settings/integrations?error=google_denied");
  }
  if (!code || !state) {
    return redirectTo("/dashboard/settings/integrations?error=google_invalid");
  }

  const userId = verifyState(state);
  if (!userId) {
    return redirectTo("/dashboard/settings/integrations?error=google_invalid_state");
  }

  const tokens = await exchangeCodeForTokens(code);
  if (!tokens) {
    // Thường do người dùng đã từng cấp quyền trước đó nên Google không trả refresh_token lần này.
    return redirectTo("/dashboard/settings/integrations?error=google_no_refresh_token");
  }

  const email = await getGoogleEmail(tokens.accessToken);

  const existing = await prisma.integration.findUnique({
    where: { ownerId_type: { ownerId: userId, type: "GOOGLE_SHEETS" } },
  });
  const previousConfig = existing?.config as
    | { spreadsheetId?: string; sheetName?: string }
    | undefined;

  await prisma.integration.upsert({
    where: { ownerId_type: { ownerId: userId, type: "GOOGLE_SHEETS" } },
    update: {
      config: {
        refreshToken: tokens.refreshToken,
        googleEmail: email ?? "",
        spreadsheetId: previousConfig?.spreadsheetId ?? "",
        sheetName: previousConfig?.sheetName ?? "",
      },
    },
    create: {
      ownerId: userId,
      type: "GOOGLE_SHEETS",
      config: {
        refreshToken: tokens.refreshToken,
        googleEmail: email ?? "",
        spreadsheetId: "",
        sheetName: "",
      },
    },
  });

  return redirectTo("/dashboard/settings/integrations?connected=google_sheets");
}
