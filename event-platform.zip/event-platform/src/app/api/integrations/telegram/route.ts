import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendTelegramMessage } from "@/lib/telegram";

const schema = z.object({
  botToken: z.string().min(1, "Vui lòng nhập Bot Token"),
  chatId: z.string().min(1, "Vui lòng nhập Chat ID"),
});

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }
  const { botToken, chatId } = parsed.data;

  const test = await sendTelegramMessage(
    botToken,
    chatId,
    "✅ Kết nối Telegram thành công! Bạn sẽ nhận thông báo tại đây mỗi khi có người đăng ký sự kiện."
  );
  if (!test.ok) {
    return NextResponse.json(
      { error: test.error ?? "Không thể gửi tin nhắn thử — kiểm tra lại Bot Token/Chat ID" },
      { status: 400 }
    );
  }

  await prisma.integration.upsert({
    where: { ownerId_type: { ownerId: userId, type: "TELEGRAM" } },
    update: { config: { botToken, chatId } },
    create: { ownerId: userId, type: "TELEGRAM", config: { botToken, chatId } },
  });

  return NextResponse.json({ ok: true });
}

export async function DELETE() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  await prisma.integration
    .delete({ where: { ownerId_type: { ownerId: userId, type: "TELEGRAM" } } })
    .catch(() => null);

  return NextResponse.json({ ok: true });
}
