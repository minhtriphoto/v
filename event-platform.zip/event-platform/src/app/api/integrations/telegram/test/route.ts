import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendTelegramMessage } from "@/lib/telegram";

export async function POST() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const integration = await prisma.integration.findUnique({
    where: { ownerId_type: { ownerId: userId, type: "TELEGRAM" } },
  });
  if (!integration) {
    return NextResponse.json({ error: "Chưa kết nối Telegram" }, { status: 404 });
  }

  const cfg = integration.config as unknown as { botToken: string; chatId: string };
  const result = await sendTelegramMessage(
    cfg.botToken,
    cfg.chatId,
    "🔔 Đây là tin nhắn thử từ Sự Kiện Cộng Đồng."
  );

  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: 400 });
  }
  return NextResponse.json({ ok: true });
}
