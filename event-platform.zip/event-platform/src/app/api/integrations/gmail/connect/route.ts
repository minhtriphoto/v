import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { buildGmailAuthUrl } from "@/lib/gmail";
import { signState } from "@/lib/oauth-state";

export async function GET() {
  const session = await auth();
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

  if (!session?.user) {
    return NextResponse.redirect(new URL("/login", appUrl));
  }
  if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
    return NextResponse.redirect(
      new URL("/dashboard/settings/integrations?error=google_not_configured", appUrl)
    );
  }

  const userId = (session.user as { id: string }).id;
  const state = signState(userId);
  return NextResponse.redirect(buildGmailAuthUrl(state));
}
