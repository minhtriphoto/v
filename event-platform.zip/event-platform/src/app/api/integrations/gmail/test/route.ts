import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { sendViaGmail } from "@/lib/gmail";

export async function POST() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const gmail = await prisma.gmailConnection.findUnique({ where: { userId } });
  if (!gmail) {
    return NextResponse.json({ error: "Chưa kết nối Gmail" }, { status: 404 });
  }

  const owner = await prisma.user.findUnique({ where: { id: userId } });
  const result = await sendViaGmail({
    refreshToken: gmail.refreshToken,
    fromName: owner?.name ?? "",
    fromEmail: gmail.gmailAddress,
    to: gmail.gmailAddress,
    subject: "Email thử từ Sự Kiện Cộng Đồng",
    html: "<p>Nếu bạn nhận được email này qua đúng hộp thư Gmail của mình, kết nối đã hoạt động chính xác 🎉</p>",
  });

  if (!result.ok) {
    return NextResponse.json({ error: result.error }, { status: 400 });
  }
  return NextResponse.json({ ok: true });
}
