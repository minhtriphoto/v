import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { exchangeCodeForTokens, getGoogleEmail } from "@/lib/google-oauth";
import { getGmailRedirectUri } from "@/lib/gmail";
import { verifyState } from "@/lib/oauth-state";

function redirectTo(path: string) {
  const base = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  return NextResponse.redirect(new URL(path, base));
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const error = url.searchParams.get("error");

  if (error) return redirectTo("/dashboard/settings/integrations?error=google_denied");
  if (!code || !state) return redirectTo("/dashboard/settings/integrations?error=google_invalid");

  const userId = verifyState(state);
  if (!userId) return redirectTo("/dashboard/settings/integrations?error=google_invalid_state");

  const tokens = await exchangeCodeForTokens(code, getGmailRedirectUri());
  if (!tokens) {
    return redirectTo("/dashboard/settings/integrations?error=google_no_refresh_token");
  }

  const email = await getGoogleEmail(tokens.accessToken);
  if (!email) {
    return redirectTo("/dashboard/settings/integrations?error=google_invalid");
  }

  await prisma.gmailConnection.upsert({
    where: { userId },
    update: { gmailAddress: email, refreshToken: tokens.refreshToken },
    create: { userId, gmailAddress: email, refreshToken: tokens.refreshToken },
  });

  return redirectTo("/dashboard/settings/integrations?connected=gmail");
}
