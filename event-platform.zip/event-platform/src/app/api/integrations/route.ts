import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const integrations = await prisma.integration.findMany({
    where: { ownerId: userId },
  });
  const gmail = await prisma.gmailConnection.findUnique({ where: { userId } });

  const telegram = integrations.find((i) => i.type === "TELEGRAM");
  const sheets = integrations.find((i) => i.type === "GOOGLE_SHEETS");

  const telegramConfig = telegram?.config as
    | { botToken: string; chatId: string }
    | undefined;
  const sheetsConfig = sheets?.config as
    | {
        refreshToken: string;
        googleEmail: string;
        spreadsheetId?: string;
        sheetName?: string;
      }
    | undefined;

  return NextResponse.json({
    telegram: telegram
      ? { connected: true, chatId: telegramConfig?.chatId }
      : { connected: false },
    googleSheets: sheets
      ? {
          connected: true,
          googleEmail: sheetsConfig?.googleEmail,
          spreadsheetId: sheetsConfig?.spreadsheetId ?? "",
          sheetName: sheetsConfig?.sheetName ?? "",
        }
      : { connected: false },
    gmail: gmail
      ? { connected: true, gmailAddress: gmail.gmailAddress }
      : { connected: false },
  });
}
