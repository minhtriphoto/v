import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { recordInteraction } from "@/lib/scoring";

// 1x1 GIF trong suốt (43 byte) — trả về luôn để không làm hỏng giao diện email
// dù việc ghi nhận có thành công hay không.
const TRANSPARENT_GIF = Buffer.from(
  "R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBTAA7",
  "base64"
);

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params;

  const recipient = await prisma.campaignRecipient.findUnique({
    where: { trackingToken: token },
    include: { campaign: true },
  });

  if (recipient && !recipient.openedAt) {
    await prisma.campaignRecipient.update({
      where: { id: recipient.id },
      data: { openedAt: new Date(), status: "OPENED" },
    });
    await recordInteraction({
      contactId: recipient.contactId,
      type: "EMAIL_OPEN",
      metadata: { campaignId: recipient.campaignId, campaignName: recipient.campaign.name },
    });
  }

  return new NextResponse(TRANSPARENT_GIF, {
    headers: {
      "Content-Type": "image/gif",
      "Cache-Control": "no-store, no-cache, must-revalidate",
    },
  });
}
