import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { recordInteraction } from "@/lib/scoring";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params;
  const url = new URL(req.url);
  const target = url.searchParams.get("u");
  const fallback = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

  if (!target) {
    return NextResponse.redirect(fallback);
  }

  const recipient = await prisma.campaignRecipient.findUnique({
    where: { trackingToken: token },
    include: { campaign: true },
  });

  if (recipient) {
    await prisma.campaignRecipient.update({
      where: { id: recipient.id },
      data: {
        clickedAt: recipient.clickedAt ?? new Date(),
        status: "CLICKED",
      },
    });
    if (!recipient.clickedAt) {
      await recordInteraction({
        contactId: recipient.contactId,
        type: "EMAIL_CLICK",
        metadata: { campaignId: recipient.campaignId, campaignName: recipient.campaign.name },
      });
    }
  }

  return NextResponse.redirect(target);
}
