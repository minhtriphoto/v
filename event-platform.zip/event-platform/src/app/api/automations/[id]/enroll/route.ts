import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { enrollContact } from "@/lib/automation-engine";

const schema = z.object({ contactId: z.string().min(1) });

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const automation = await prisma.automation.findUnique({ where: { id } });
  if (!automation || automation.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy automation" }, { status: 404 });
  }

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Thiếu contactId" }, { status: 400 });
  }

  const contact = await prisma.contact.findUnique({ where: { id: parsed.data.contactId } });
  if (!contact || contact.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy khách hàng" }, { status: 404 });
  }

  await enrollContact({ automationId: id, contactId: contact.id });
  return NextResponse.json({ ok: true });
}
