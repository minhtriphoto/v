import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { processAutomationNow } from "@/lib/automation-engine";

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const automation = await prisma.automation.findUnique({ where: { id } });
  if (!automation || automation.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy automation" }, { status: 404 });
  }

  const result = await processAutomationNow(id);
  return NextResponse.json(result);
}
