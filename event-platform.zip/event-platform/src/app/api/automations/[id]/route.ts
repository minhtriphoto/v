import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const blockSchema = z.object({
  id: z.string(),
  type: z.enum(["heading", "paragraph", "button", "image", "divider", "spacer"]),
  text: z.string().optional(),
  url: z.string().optional(),
  alt: z.string().optional(),
});

const stepSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("SEND_EMAIL"),
    config: z.object({ subject: z.string().min(1), contentBlocks: z.array(blockSchema) }),
  }),
  z.object({
    type: z.literal("WAIT"),
    config: z.object({ hours: z.number().positive() }),
  }),
  z.object({
    type: z.literal("CONDITION_BRANCH"),
    config: z.object({
      minScore: z.number(),
      ifTrueOrder: z.number().int(),
      ifFalseOrder: z.number().int(),
    }),
  }),
  z.object({
    type: z.literal("ADD_TAG"),
    config: z.object({ tagName: z.string().min(1), color: z.string().optional() }),
  }),
]);

async function requireOwnedAutomation(id: string, userId: string) {
  const automation = await prisma.automation.findUnique({ where: { id } });
  if (!automation || automation.ownerId !== userId) return null;
  return automation;
}

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const automation = await prisma.automation.findUnique({
    where: { id },
    include: {
      event: { select: { id: true, title: true } },
      steps: { orderBy: { order: "asc" } },
      enrollments: true,
    },
  });
  if (!automation || automation.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy automation" }, { status: 404 });
  }

  const stats = {
    total: automation.enrollments.length,
    running: automation.enrollments.filter((e) => e.status === "RUNNING").length,
    completed: automation.enrollments.filter((e) => e.status === "COMPLETED").length,
    failed: automation.enrollments.filter((e) => e.status === "FAILED").length,
  };

  return NextResponse.json({ ...automation, stats });
}

const updateSchema = z.object({
  name: z.string().min(1).optional(),
  status: z.enum(["ACTIVE", "PAUSED"]).optional(),
  steps: z.array(stepSchema).optional(),
});

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const owned = await requireOwnedAutomation(id, userId);
  if (!owned) {
    return NextResponse.json({ error: "Không tìm thấy automation" }, { status: 404 });
  }

  const body = await req.json().catch(() => null);
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }
  const { steps, ...rest } = parsed.data;

  await prisma.$transaction(async (tx) => {
    if (Object.keys(rest).length > 0) {
      await tx.automation.update({ where: { id }, data: rest });
    }
    if (steps) {
      await tx.automationStep.deleteMany({ where: { automationId: id } });
      await tx.automationStep.createMany({
        data: steps.map((s, i) => ({
          automationId: id,
          order: i,
          type: s.type,
          config: s.config,
        })),
      });
    }
  });

  const automation = await prisma.automation.findUnique({
    where: { id },
    include: { steps: { orderBy: { order: "asc" } } },
  });
  return NextResponse.json(automation);
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const owned = await requireOwnedAutomation(id, userId);
  if (!owned) {
    return NextResponse.json({ error: "Không tìm thấy automation" }, { status: 404 });
  }
  await prisma.automation.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
