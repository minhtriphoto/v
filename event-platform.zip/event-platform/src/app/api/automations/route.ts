import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const createSchema = z.object({
  name: z.string().min(1, "Vui lòng đặt tên automation"),
  eventId: z.string().nullable(),
  triggerType: z.enum(["ON_REGISTER", "ON_APPROVED", "DAYS_BEFORE_EVENT", "DAYS_AFTER_EVENT", "MANUAL"]),
  offsetDays: z.number().int().min(0).nullable().optional(),
});

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const automations = await prisma.automation.findMany({
    where: { ownerId: userId },
    orderBy: { createdAt: "desc" },
    include: {
      event: { select: { title: true } },
      _count: { select: { steps: true, enrollments: true } },
    },
  });
  return NextResponse.json(automations);
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }
  const { name, eventId, triggerType, offsetDays } = parsed.data;

  if (triggerType !== "MANUAL" && !eventId) {
    return NextResponse.json(
      { error: "Vui lòng chọn sự kiện áp dụng automation này" },
      { status: 400 }
    );
  }
  if ((triggerType === "DAYS_BEFORE_EVENT" || triggerType === "DAYS_AFTER_EVENT") && offsetDays == null) {
    return NextResponse.json(
      { error: "Vui lòng nhập số ngày" },
      { status: 400 }
    );
  }

  if (eventId) {
    const event = await prisma.event.findUnique({ where: { id: eventId } });
    if (!event || event.ownerId !== userId) {
      return NextResponse.json({ error: "Sự kiện không hợp lệ" }, { status: 400 });
    }
  }

  const automation = await prisma.automation.create({
    data: {
      ownerId: userId,
      name,
      eventId: triggerType === "MANUAL" ? null : eventId,
      triggerType,
      offsetDays: offsetDays ?? null,
    },
  });

  return NextResponse.json(automation, { status: 201 });
}
