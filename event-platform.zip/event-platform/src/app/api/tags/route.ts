import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const tags = await prisma.tag.findMany({
    where: { ownerId: userId },
    orderBy: { name: "asc" },
  });
  return NextResponse.json(tags);
}

const schema = z.object({
  name: z.string().min(1, "Vui lòng nhập tên thẻ"),
  color: z.string().optional(),
});

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }

  const existing = await prisma.tag.findUnique({
    where: { ownerId_name: { ownerId: userId, name: parsed.data.name } },
  });
  if (existing) return NextResponse.json(existing);

  const tag = await prisma.tag.create({
    data: {
      ownerId: userId,
      name: parsed.data.name,
      color: parsed.data.color || "#3730a9",
    },
  });
  return NextResponse.json(tag, { status: 201 });
}
