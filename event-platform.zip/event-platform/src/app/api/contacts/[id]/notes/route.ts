import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { recordInteraction } from "@/lib/scoring";

const schema = z.object({
  note: z.string().min(1, "Vui lòng nhập nội dung ghi chú"),
});

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const contact = await prisma.contact.findUnique({ where: { id } });
  if (!contact || contact.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy khách hàng" }, { status: 404 });
  }

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }

  await recordInteraction({
    contactId: id,
    type: "MANUAL_NOTE",
    metadata: { note: parsed.data.note },
  });

  return NextResponse.json({ ok: true });
}
