import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { recordInteraction } from "@/lib/scoring";

const schema = z.object({
  tagId: z.string().optional(),
  name: z.string().optional(),
  color: z.string().optional(),
});

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id: contactId } = await params;

  const contact = await prisma.contact.findUnique({ where: { id: contactId } });
  if (!contact || contact.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy khách hàng" }, { status: 404 });
  }

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success || (!parsed.data.tagId && !parsed.data.name)) {
    return NextResponse.json({ error: "Vui lòng chọn hoặc nhập tên thẻ" }, { status: 400 });
  }

  let tagId = parsed.data.tagId;
  if (!tagId && parsed.data.name) {
    const tag = await prisma.tag.upsert({
      where: { ownerId_name: { ownerId: userId, name: parsed.data.name } },
      update: {},
      create: {
        ownerId: userId,
        name: parsed.data.name,
        color: parsed.data.color || "#3730a9",
      },
    });
    tagId = tag.id;
  }

  const tag = await prisma.tag.findUnique({ where: { id: tagId } });
  if (!tag || tag.ownerId !== userId) {
    return NextResponse.json({ error: "Thẻ không hợp lệ" }, { status: 400 });
  }

  await prisma.contactTag.upsert({
    where: { contactId_tagId: { contactId, tagId: tag.id } },
    update: {},
    create: { contactId, tagId: tag.id },
  });

  await recordInteraction({
    contactId,
    type: "TAG_ADDED",
    metadata: { tagName: tag.name },
  });

  return NextResponse.json({ ok: true, tag });
}
