import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string; tagId: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id: contactId, tagId } = await params;

  const contact = await prisma.contact.findUnique({ where: { id: contactId } });
  if (!contact || contact.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy khách hàng" }, { status: 404 });
  }

  await prisma.contactTag
    .delete({ where: { contactId_tagId: { contactId, tagId } } })
    .catch(() => null);

  return NextResponse.json({ ok: true });
}
