import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

async function requireOwnedContact(contactId: string, userId: string) {
  const contact = await prisma.contact.findUnique({ where: { id: contactId } });
  if (!contact || contact.ownerId !== userId) return null;
  return contact;
}

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const contact = await prisma.contact.findUnique({
    where: { id },
    include: {
      tags: { include: { tag: true } },
      interactions: { orderBy: { createdAt: "desc" } },
      registrations: {
        include: { event: { select: { id: true, title: true, slug: true } } },
        orderBy: { registeredAt: "desc" },
      },
    },
  });
  if (!contact || contact.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy khách hàng" }, { status: 404 });
  }
  return NextResponse.json(contact);
}

const updateSchema = z.object({
  name: z.string().min(1).optional(),
  phone: z.string().optional(),
});

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const owned = await requireOwnedContact(id, userId);
  if (!owned) {
    return NextResponse.json({ error: "Không tìm thấy khách hàng" }, { status: 404 });
  }

  const body = await req.json().catch(() => null);
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }

  const contact = await prisma.contact.update({
    where: { id },
    data: parsed.data,
  });
  return NextResponse.json(contact);
}
