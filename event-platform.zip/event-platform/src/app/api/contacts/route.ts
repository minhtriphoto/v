import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const url = new URL(req.url);
  const search = url.searchParams.get("q")?.trim();
  const tagId = url.searchParams.get("tag");
  const sort = url.searchParams.get("sort") ?? "score";

  const contacts = await prisma.contact.findMany({
    where: {
      ownerId: userId,
      ...(search
        ? {
            OR: [
              { email: { contains: search, mode: "insensitive" } },
              { name: { contains: search, mode: "insensitive" } },
            ],
          }
        : {}),
      ...(tagId ? { tags: { some: { tagId } } } : {}),
    },
    include: {
      tags: { include: { tag: true } },
      _count: { select: { registrations: true } },
    },
    orderBy:
      sort === "recent" ? { createdAt: "desc" } : { score: "desc" },
  });

  return NextResponse.json(contacts);
}
