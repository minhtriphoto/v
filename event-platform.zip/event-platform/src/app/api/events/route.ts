import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { slugify, withRandomSuffix } from "@/lib/slug";

const questionSchema = z.object({
  label: z.string().min(1),
  type: z.enum(["TEXT", "TEXTAREA", "SELECT", "CHECKBOX", "NUMBER"]),
  options: z.array(z.string()).optional(),
  required: z.boolean().default(false),
});

const createEventSchema = z.object({
  title: z.string().min(1, "Vui lòng nhập tên sự kiện"),
  description: z.string().optional(),
  coverImageUrl: z.string().optional(),
  startTime: z.string().min(1, "Vui lòng chọn thời gian bắt đầu"),
  endTime: z.string().optional(),
  locationType: z.enum(["ONLINE", "OFFLINE", "HYBRID"]),
  address: z.string().optional(),
  onlineLink: z.string().optional(),
  capacity: z.number().int().positive().nullable().optional(),
  price: z.number().int().nonnegative().default(0),
  requiresApproval: z.boolean().default(false),
  questions: z.array(questionSchema).default([]),
});

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }

  const events = await prisma.event.findMany({
    where: { ownerId: (session.user as { id: string }).id },
    orderBy: { startTime: "desc" },
    include: { _count: { select: { registrations: true } } },
  });

  return NextResponse.json(events);
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const parsed = createEventSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }

  const data = parsed.data;
  const ownerId = (session.user as { id: string }).id;

  let slug = slugify(data.title);
  const existing = await prisma.event.findUnique({ where: { slug } });
  if (existing) slug = withRandomSuffix(slug);

  const event = await prisma.event.create({
    data: {
      ownerId,
      title: data.title,
      slug,
      description: data.description,
      coverImageUrl: data.coverImageUrl,
      startTime: new Date(data.startTime),
      endTime: data.endTime ? new Date(data.endTime) : null,
      locationType: data.locationType,
      address: data.address,
      onlineLink: data.onlineLink,
      capacity: data.capacity ?? null,
      price: data.price,
      requiresApproval: data.requiresApproval,
      questions: {
        create: data.questions.map((q, i) => ({
          label: q.label,
          type: q.type,
          options: q.options ?? undefined,
          required: q.required,
          order: i,
        })),
      },
    },
  });

  return NextResponse.json(event, { status: 201 });
}
