import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

async function requireOwnedEvent(eventId: string, userId: string) {
  const event = await prisma.event.findUnique({ where: { id: eventId } });
  if (!event || event.ownerId !== userId) return null;
  return event;
}

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const { id } = await params;
  const event = await prisma.event.findUnique({
    where: { id },
    include: { questions: { orderBy: { order: "asc" } } },
  });
  if (!event || event.ownerId !== (session.user as { id: string }).id) {
    return NextResponse.json({ error: "Không tìm thấy sự kiện" }, { status: 404 });
  }
  return NextResponse.json(event);
}

const updateSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  coverImageUrl: z.string().optional(),
  startTime: z.string().optional(),
  endTime: z.string().nullable().optional(),
  locationType: z.enum(["ONLINE", "OFFLINE", "HYBRID"]).optional(),
  address: z.string().optional(),
  onlineLink: z.string().optional(),
  capacity: z.number().int().positive().nullable().optional(),
  price: z.number().int().nonnegative().optional(),
  requiresApproval: z.boolean().optional(),
  status: z.enum(["DRAFT", "PUBLISHED", "CANCELED"]).optional(),
});

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const { id } = await params;
  const owned = await requireOwnedEvent(id, (session.user as { id: string }).id);
  if (!owned) {
    return NextResponse.json({ error: "Không tìm thấy sự kiện" }, { status: 404 });
  }

  const body = await req.json().catch(() => null);
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }
  const { startTime, endTime, ...rest } = parsed.data;

  const event = await prisma.event.update({
    where: { id },
    data: {
      ...rest,
      ...(startTime ? { startTime: new Date(startTime) } : {}),
      ...(endTime !== undefined
        ? { endTime: endTime ? new Date(endTime) : null }
        : {}),
    },
  });

  return NextResponse.json(event);
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const { id } = await params;
  const owned = await requireOwnedEvent(id, (session.user as { id: string }).id);
  if (!owned) {
    return NextResponse.json({ error: "Không tìm thấy sự kiện" }, { status: 404 });
  }
  await prisma.event.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
