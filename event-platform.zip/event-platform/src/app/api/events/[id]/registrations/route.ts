import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const { id } = await params;
  const userId = (session.user as { id: string }).id;

  const event = await prisma.event.findUnique({
    where: { id },
    include: { questions: { orderBy: { order: "asc" } } },
  });
  if (!event || event.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy sự kiện" }, { status: 404 });
  }

  const registrations = await prisma.registration.findMany({
    where: { eventId: id },
    orderBy: { registeredAt: "desc" },
    include: { answers: true },
  });

  const url = new URL(req.url);
  if (url.searchParams.get("export") === "csv") {
    const headers = [
      "Tên",
      "Email",
      "Trạng thái",
      "Đăng ký lúc",
      ...event.questions.map((q) => q.label),
    ];
    const rows = registrations.map((r) => {
      const byQuestion = Object.fromEntries(
        r.answers.map((a) => [a.questionId, a.value])
      );
      return [
        r.name,
        r.email,
        r.status,
        r.registeredAt.toISOString(),
        ...event.questions.map((q) => byQuestion[q.id] ?? ""),
      ];
    });
    const csv = [headers, ...rows]
      .map((row) =>
        row
          .map((cell) => `"${String(cell).replace(/"/g, '""')}"`)
          .join(",")
      )
      .join("\n");

    return new NextResponse("\uFEFF" + csv, {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="${event.slug}-danh-sach.csv"`,
      },
    });
  }

  return NextResponse.json(registrations);
}
