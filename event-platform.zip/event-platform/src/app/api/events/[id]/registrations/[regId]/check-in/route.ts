import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { recordInteraction } from "@/lib/scoring";

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string; regId: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const { id, regId } = await params;
  const userId = (session.user as { id: string }).id;

  const event = await prisma.event.findUnique({ where: { id } });
  if (!event || event.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy sự kiện" }, { status: 404 });
  }

  const registration = await prisma.registration.findUnique({ where: { id: regId } });
  if (!registration || registration.eventId !== id) {
    return NextResponse.json({ error: "Không tìm thấy người đăng ký" }, { status: 404 });
  }

  const checkingIn = !registration.checkedInAt;

  const updated = await prisma.registration.update({
    where: { id: regId },
    data: { checkedInAt: checkingIn ? new Date() : null },
  });

  if (checkingIn) {
    await recordInteraction({
      contactId: registration.contactId,
      type: "CHECK_IN",
      metadata: { eventId: event.id, eventTitle: event.title },
    });
  }

  return NextResponse.json(updated);
}
