import { NextResponse, after } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { recordInteraction } from "@/lib/scoring";
import { triggerEventAutomations } from "@/lib/automation-engine";

const updateSchema = z.object({
  status: z.enum(["APPROVED", "REJECTED", "CANCELED", "PENDING"]),
});

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string; regId: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const { id, regId } = await params;
  const userId = (session.user as { id: string }).id;

  const event = await prisma.event.findUnique({ where: { id } });
  if (!event || event.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy sự kiện" }, { status: 404 });
  }

  const body = await req.json().catch(() => null);
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Trạng thái không hợp lệ" }, { status: 400 });
  }

  const registration = await prisma.registration.findUnique({
    where: { id: regId },
  });
  if (!registration || registration.eventId !== id) {
    return NextResponse.json({ error: "Không tìm thấy người đăng ký" }, { status: 404 });
  }

  const updated = await prisma.registration.update({
    where: { id: regId },
    data: { status: parsed.data.status },
  });

  if (parsed.data.status === "APPROVED" && registration.status !== "APPROVED") {
    await recordInteraction({
      contactId: registration.contactId,
      type: "APPROVED",
      metadata: { eventId: event.id, eventTitle: event.title },
    });
    after(() =>
      triggerEventAutomations({
        triggerType: "ON_APPROVED",
        eventId: event.id,
        contactId: registration.contactId,
        registrationId: registration.id,
      }).catch(() => {})
    );
  }

  return NextResponse.json(updated);
}
