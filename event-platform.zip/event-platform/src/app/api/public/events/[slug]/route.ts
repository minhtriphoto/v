import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const event = await prisma.event.findUnique({
    where: { slug },
    include: {
      questions: { orderBy: { order: "asc" } },
      owner: { select: { name: true } },
      _count: {
        select: { registrations: { where: { status: "APPROVED" } } },
      },
    },
  });

  if (!event || event.status !== "PUBLISHED") {
    return NextResponse.json({ error: "Không tìm thấy sự kiện" }, { status: 404 });
  }

  const spotsLeft =
    event.capacity != null
      ? Math.max(event.capacity - event._count.registrations, 0)
      : null;

  return NextResponse.json({
    id: event.id,
    title: event.title,
    slug: event.slug,
    description: event.description,
    coverImageUrl: event.coverImageUrl,
    startTime: event.startTime,
    endTime: event.endTime,
    timezone: event.timezone,
    locationType: event.locationType,
    address: event.address,
    onlineLink: event.onlineLink,
    price: event.price,
    currency: event.currency,
    requiresApproval: event.requiresApproval,
    capacity: event.capacity,
    spotsLeft,
    organizerName: event.owner.name,
    questions: event.questions,
    approvedCount: event._count.registrations,
  });
}
