import { NextResponse, after } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { notifyNewRegistration } from "@/lib/notify-registration";
import { upsertContactForRegistration, recordInteraction } from "@/lib/scoring";
import { triggerEventAutomations } from "@/lib/automation-engine";

const registerSchema = z.object({
  name: z.string().min(1, "Vui lòng nhập tên"),
  email: z.string().email("Email không hợp lệ"),
  answers: z.record(z.string(), z.string()).default({}),
});

export async function POST(
  req: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const event = await prisma.event.findUnique({
    where: { slug },
    include: {
      questions: true,
      _count: {
        select: { registrations: { where: { status: "APPROVED" } } },
      },
    },
  });

  if (!event || event.status !== "PUBLISHED") {
    return NextResponse.json({ error: "Không tìm thấy sự kiện" }, { status: 404 });
  }

  const body = await req.json().catch(() => null);
  const parsed = registerSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }
  const { name, email, answers } = parsed.data;

  // Kiểm tra câu hỏi bắt buộc
  for (const q of event.questions) {
    if (q.required && !answers[q.id]?.trim()) {
      return NextResponse.json(
        { error: `Vui lòng trả lời: ${q.label}` },
        { status: 400 }
      );
    }
  }

  // Kiểm tra còn chỗ trống
  if (event.capacity != null && event._count.registrations >= event.capacity) {
    return NextResponse.json(
      { error: "Sự kiện đã đủ số lượng đăng ký" },
      { status: 409 }
    );
  }

  const existing = await prisma.registration.findUnique({
    where: { eventId_email: { eventId: event.id, email } },
  });
  if (existing) {
    return NextResponse.json(
      { error: "Email này đã đăng ký sự kiện" },
      { status: 409 }
    );
  }

  const contact = await upsertContactForRegistration({
    ownerId: event.ownerId,
    email,
    name,
    source: `event:${event.slug}`,
  });

  const registration = await prisma.registration.create({
    data: {
      eventId: event.id,
      contactId: contact.id,
      name,
      email,
      status: event.requiresApproval ? "PENDING" : "APPROVED",
      answers: {
        create: Object.entries(answers)
          .filter(([, value]) => value?.trim())
          .map(([questionId, value]) => ({ questionId, value })),
      },
    },
  });

  await recordInteraction({
    contactId: contact.id,
    type: "REGISTER",
    metadata: { eventId: event.id, eventTitle: event.title },
  });
  if (registration.status === "APPROVED") {
    await recordInteraction({
      contactId: contact.id,
      type: "APPROVED",
      metadata: { eventId: event.id, eventTitle: event.title },
    });
  }

  // Chạy nền — kích hoạt automation không nên làm chậm phản hồi cho khách
  after(async () => {
    await triggerEventAutomations({
      triggerType: "ON_REGISTER",
      eventId: event.id,
      contactId: contact.id,
      registrationId: registration.id,
    }).catch(() => {});
    if (registration.status === "APPROVED") {
      await triggerEventAutomations({
        triggerType: "ON_APPROVED",
        eventId: event.id,
        contactId: contact.id,
        registrationId: registration.id,
      }).catch(() => {});
    }
  });

  // Best-effort, chạy nền sau khi phản hồi đã gửi cho khách (an toàn trên serverless nhờ after())
  after(() =>
    notifyNewRegistration({
      ownerId: event.ownerId,
      eventId: event.id,
      eventTitle: event.title,
      eventSlug: event.slug,
      registrantName: name,
      registrantEmail: email,
      status: registration.status as "PENDING" | "APPROVED",
      answers,
      questions: event.questions.map((q) => ({ id: q.id, label: q.label })),
    }).catch(() => {})
  );

  return NextResponse.json(
    { id: registration.id, status: registration.status },
    { status: 201 }
  );
}
