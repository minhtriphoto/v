import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const blockSchema = z.object({
  id: z.string(),
  type: z.enum(["heading", "paragraph", "button", "image", "divider", "spacer"]),
  text: z.string().optional(),
  url: z.string().optional(),
  alt: z.string().optional(),
});

async function requireOwnedCampaign(id: string, userId: string) {
  const campaign = await prisma.campaign.findUnique({ where: { id } });
  if (!campaign || campaign.ownerId !== userId) return null;
  return campaign;
}

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const campaign = await prisma.campaign.findUnique({
    where: { id },
    include: {
      recipients: {
        include: { contact: { select: { email: true, name: true } } },
        orderBy: { sentAt: "desc" },
      },
    },
  });
  if (!campaign || campaign.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy chiến dịch" }, { status: 404 });
  }

  const total = campaign.recipients.length;
  const sent = campaign.recipients.filter((r) => r.status !== "PENDING" && r.status !== "FAILED").length;
  const opened = campaign.recipients.filter((r) => r.openedAt).length;
  const clicked = campaign.recipients.filter((r) => r.clickedAt).length;
  const failed = campaign.recipients.filter((r) => r.status === "FAILED").length;

  return NextResponse.json({
    ...campaign,
    stats: { total, sent, opened, clicked, failed },
  });
}

const updateSchema = z.object({
  name: z.string().min(1).optional(),
  subject: z.string().min(1).optional(),
  contentBlocks: z.array(blockSchema).optional(),
  filterQuery: z
    .object({
      tagIds: z.array(z.string()).optional(),
      minScore: z.number().optional(),
    })
    .optional(),
});

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const owned = await requireOwnedCampaign(id, userId);
  if (!owned) {
    return NextResponse.json({ error: "Không tìm thấy chiến dịch" }, { status: 404 });
  }
  if (owned.status !== "DRAFT") {
    return NextResponse.json(
      { error: "Chỉ có thể chỉnh sửa chiến dịch ở trạng thái nháp" },
      { status: 400 }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }

  const campaign = await prisma.campaign.update({
    where: { id },
    data: parsed.data,
  });
  return NextResponse.json(campaign);
}

export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const owned = await requireOwnedCampaign(id, userId);
  if (!owned) {
    return NextResponse.json({ error: "Không tìm thấy chiến dịch" }, { status: 404 });
  }
  await prisma.campaign.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
