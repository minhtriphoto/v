import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { resolveAudience } from "@/lib/campaign-audience";
import { renderBlocksToHtml, type EmailBlock } from "@/lib/email-blocks";
import { sendEmailBatch } from "@/lib/email-sender";
import { sendEmailForOwner } from "@/lib/email-dispatch";
import { signUnsubscribeToken } from "@/lib/unsubscribe-token";
import { recordInteraction } from "@/lib/scoring";

// Giới hạn số người nhận gửi được trong 1 lần bấm — tránh serverless function
// timeout. Danh sách lớn hơn nên được chia nhỏ (cải thiện ở Automation/queue
// sau này). Với Vercel Hobby (10s) nên đặt thấp; Pro (300s) có thể tăng.
const MAX_RECIPIENTS_PER_SEND = Number(process.env.CAMPAIGN_MAX_RECIPIENTS ?? 300);

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;
  const { id } = await params;

  const campaign = await prisma.campaign.findUnique({ where: { id } });
  if (!campaign || campaign.ownerId !== userId) {
    return NextResponse.json({ error: "Không tìm thấy chiến dịch" }, { status: 404 });
  }
  if (campaign.status !== "DRAFT") {
    return NextResponse.json(
      { error: "Chiến dịch này đã được gửi trước đó" },
      { status: 400 }
    );
  }

  const gmailConnected = await prisma.gmailConnection.findUnique({ where: { userId } });
  if (!gmailConnected && (!process.env.RESEND_API_KEY || !process.env.RESEND_FROM_EMAIL)) {
    return NextResponse.json(
      {
        error:
          "Chưa cấu hình cách gửi email — kết nối Gmail cá nhân hoặc cấu hình RESEND_API_KEY/RESEND_FROM_EMAIL trên server",
      },
      { status: 400 }
    );
  }

  const filter = campaign.filterQuery as { tagIds?: string[]; minScore?: number };
  const audience = await resolveAudience(userId, filter);

  if (audience.length === 0) {
    return NextResponse.json(
      { error: "Không có người nhận nào phù hợp với bộ lọc" },
      { status: 400 }
    );
  }
  if (audience.length > MAX_RECIPIENTS_PER_SEND) {
    return NextResponse.json(
      {
        error: `Danh sách có ${audience.length} người, vượt giới hạn ${MAX_RECIPIENTS_PER_SEND} người/lần gửi của giai đoạn này. Hãy thu hẹp bộ lọc (theo thẻ/điểm) rồi gửi thành nhiều đợt.`,
      },
      { status: 400 }
    );
  }

  const owner = await prisma.user.findUnique({ where: { id: userId } });
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

  await prisma.campaign.update({ where: { id }, data: { status: "SENDING" } });

  // Tạo sẵn bản ghi recipient cho từng người (kể cả nếu gửi lỗi, vẫn có record để biết)
  const recipients = await Promise.all(
    audience.map((contact) =>
      prisma.campaignRecipient.upsert({
        where: { campaignId_contactId: { campaignId: id, contactId: contact.id } },
        update: {},
        create: { campaignId: id, contactId: contact.id },
      })
    )
  );

  const blocks = campaign.contentBlocks as unknown as EmailBlock[];
  const contactById = new Map(audience.map((c) => [c.id, c]));

  let sentCount = 0;
  let failedCount = 0;

  await sendEmailBatch(recipients, async (recipient) => {
    const contact = contactById.get(recipient.contactId);
    if (!contact) return;

    const unsubscribeUrl = `${appUrl}/unsubscribe/${signUnsubscribeToken(contact.id)}`;
    const html = renderBlocksToHtml(blocks, {
      unsubscribeUrl,
      organizerName: owner?.name ?? undefined,
      appUrl,
      trackingToken: recipient.trackingToken,
    });

    const result = await sendEmailForOwner(userId, { to: contact.email, subject: campaign.subject, html });

    if (result.ok) {
      sentCount++;
      await prisma.campaignRecipient.update({
        where: { id: recipient.id },
        data: { status: "SENT", sentAt: new Date() },
      });
      await recordInteraction({
        contactId: contact.id,
        type: "EMAIL_SENT",
        metadata: { campaignId: id, campaignName: campaign.name },
      });
    } else {
      failedCount++;
      await prisma.campaignRecipient.update({
        where: { id: recipient.id },
        data: { status: "FAILED", errorMessage: result.error },
      });
    }
  });

  await prisma.campaign.update({
    where: { id },
    data: { status: "SENT", sentAt: new Date() },
  });

  return NextResponse.json({ ok: true, sent: sentCount, failed: failedCount });
}
