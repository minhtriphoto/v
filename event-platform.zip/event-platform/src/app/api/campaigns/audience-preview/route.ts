import { NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { countAudience } from "@/lib/campaign-audience";

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const body = await req.json().catch(() => ({}));
  const count = await countAudience(userId, {
    tagIds: body.tagIds ?? [],
    minScore: body.minScore,
  });

  return NextResponse.json({ count });
}
