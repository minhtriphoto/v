import { NextResponse } from "next/server";
import { z } from "zod";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const blockSchema = z.object({
  id: z.string(),
  type: z.enum(["heading", "paragraph", "button", "image", "divider", "spacer"]),
  text: z.string().optional(),
  url: z.string().optional(),
  alt: z.string().optional(),
});

const createSchema = z.object({
  name: z.string().min(1, "Vui lòng đặt tên chiến dịch"),
  subject: z.string().min(1, "Vui lòng nhập tiêu đề email"),
  contentBlocks: z.array(blockSchema).default([]),
  filterQuery: z
    .object({
      tagIds: z.array(z.string()).optional(),
      minScore: z.number().optional(),
    })
    .default({}),
});

export async function GET() {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const campaigns = await prisma.campaign.findMany({
    where: { ownerId: userId },
    orderBy: { createdAt: "desc" },
    include: {
      _count: { select: { recipients: true } },
    },
  });

  return NextResponse.json(campaigns);
}

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user) {
    return NextResponse.json({ error: "Chưa đăng nhập" }, { status: 401 });
  }
  const userId = (session.user as { id: string }).id;

  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Dữ liệu không hợp lệ" },
      { status: 400 }
    );
  }

  const campaign = await prisma.campaign.create({
    data: {
      ownerId: userId,
      name: parsed.data.name,
      subject: parsed.data.subject,
      contentBlocks: parsed.data.contentBlocks,
      filterQuery: parsed.data.filterQuery,
    },
  });

  return NextResponse.json(campaign, { status: 201 });
}
